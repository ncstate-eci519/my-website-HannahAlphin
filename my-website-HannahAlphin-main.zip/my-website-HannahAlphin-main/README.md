<h1>Hannah Alphin</h1>
<h2>About Me</h2>
<p>I graduated from UNC-Chapel Hill in 2019 and developed an interest for the relationship between learning and technology there. 
As a result, I decided to apply to the LDT master's program at NCSU. This is my first class I have had on coding and I am excited to 
learn and utlize this skill. Currently, I work as a Junior Instructional Designer for a company that develops eLearning training material 
for the military.</p>
<p> Some facts about me:</p>
<ul>
<li>I majored in English and minored in CRDL (<b>C</b>omposition, <b>R</b>hetoric and <b>D</b>igital <b>L</b>iteracy).</li>
<li>I love animals. I have two dogs (a Boxer and a Jack Russell Terrier).</li>
<li>I love the outdoors and always enjoy finidng new hiking trails to check out.</li>
<li>My favority genre of movies and TV is Sci-Fi.</li>
</ul>

<h2>My Favorite Ed Tech Tools</h2>
<ol>
<li>Articulate Storyline 360</li>
I am very familar with Storyline 360 because I use it at my job. It is a great software for creating interactive eLearning content.
<li>Camtasia</li>
I used Camtasia a lot during my undergrad to edit videos for projects. I like how easy it is to learn and navigate.
<li>Powtoon</li>
I have used Powtoon in the past to create animated explainer videos. I enjoy how it allows you to add characters and graphics to make
your videos more visually interesting. 
